import 'package:flutter/material.dart';
import 'home_page.dart';

void main() {
  runApp(const OceanExpenseApp());
}

class OceanExpenseApp extends StatelessWidget {
  const OceanExpenseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Ocean Expense Tracker",
      debugShowCheckedModeBanner: false,
      home: const HomePage(),
    );
  }
}